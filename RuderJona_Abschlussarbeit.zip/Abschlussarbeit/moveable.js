"use strict";
var EIA2SoSe23_Abschlussarbeit;
(function (EIA2SoSe23_Abschlussarbeit) {
    /*
Aufgabe: Abschlussarbeit EIA2 SoSe 23
Name: Jona Ruder
Matrikel: 265274
Datum: 16.07.2023
Quellen: -
*/
    class Moveable {
        constructor(_posX, _posY, _scaling) {
            this.posX = _posX;
            this.posY = _posY;
            this.scaling = _scaling;
        }
    }
    EIA2SoSe23_Abschlussarbeit.Moveable = Moveable;
})(EIA2SoSe23_Abschlussarbeit || (EIA2SoSe23_Abschlussarbeit = {}));
//# sourceMappingURL=moveable.js.map